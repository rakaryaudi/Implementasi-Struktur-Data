package Jurnal2ISD;

public class Barang implements Comparable<Barang>{
    String kdBarang;
    String jenisBarang;
    String namaBarang;
    int jumlahStok;

    public Barang(String kdBarang, String jenisBarang, String namaBarang, int jumlahStok){
        if(!(kdBarang.split("")[0].equals("A") || kdBarang.split("")[0].equals("B"))){
            throw new IllegalArgumentException("Kode Barang yang dimasukan harus A atau B");
        }
        this.kdBarang = kdBarang;
        this.jenisBarang = jenisBarang;
        this.namaBarang = namaBarang;
        this.jumlahStok = jumlahStok;
    }

    public String getKdBarang(){
        return kdBarang;
    }

    @Override
    public String toString(){
        return  kdBarang + " " + jenisBarang + " " + namaBarang + " " + jumlahStok + " | ";
    }

    @Override
    public int compareTo(Barang o){
        return this.getKdBarang().compareTo(o.getKdBarang());
    }
}
