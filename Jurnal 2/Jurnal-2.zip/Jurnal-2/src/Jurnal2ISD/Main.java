package Jurnal2ISD;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        GenArrayList<Barang> barangList = new GenArrayList<>(3);
        GenArrayList<Bag> bagList = new GenArrayList<>(1);

        // untuk Barang
        for (int i = 0; i < 5; i++){
            String kdBarang = input.next();
            String jenisBarang = input.next();
            String namaBarag = input.next();
            int jumlahStok = input.nextInt();
            barangList.addData(new Barang(kdBarang, jenisBarang, namaBarag, jumlahStok));
        }

        Barang barangAdd = new Barang("A001", "Tas", "Pensi Hitam", 14);
        barangList.addData(barangAdd);
        barangList.displaySort();;
        System.out.println("dibawah ini adalah data yang sudah di edit");
        Barang barangEdit = new Barang("A002", "Tas edit", "Pensil Putih edit", 24);
        barangList.editData(barangAdd, barangEdit);
        barangList.display();
        System.out.println("dibawah ini adalah data yang sudah di remove");
        barangList.removeData(barangEdit);
        barangList.display();

        System.out.println();

        //untuk Bag
        for(int i=0; i<5; i++){
            String kdBarang = input.next();
            String jenisBarang = input.next();
            String namaBarang = input.next();
            int jumlahStok = input.nextInt();
            bagList.addData(new Bag(kdBarang,jenisBarang, namaBarang, jumlahStok));
        }

        Bag bagAdd = new Bag("C001", "tas", "tas hitam", 12);
        bagList.addData(bagAdd);
        bagList.displaySort();
        Bag bagEdit = new Bag("C001", "tas edit", "tas hitam edit", 23);
        bagList.editData(bagAdd, bagEdit);
        System.out.println("dibawah ini data yang sudah di edit");
        bagList.display();
        bagList.removeData(bagEdit);
        System.out.println("dibawah ini data yang sudah di remove");
        bagList.display();
    }
}
